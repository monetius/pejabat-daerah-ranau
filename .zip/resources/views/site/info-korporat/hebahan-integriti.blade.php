@extends('layouts.site')

@section('title', 'Hebahan Integriti - Pejabat Daerah Ranau')
@section('description', 'Hebahan Integriti daripada Bahagian Integriti dan Governans Negeri Sabah (BIGONS) - dasar antirasuah, tanda nama, tadbir urus baik dan cara melaporkan rasuah.')
@section('body_class', 'has-banner')

@push('styles')
  <link rel="stylesheet" href="{{ asset('assets/css/integ.css') }}">
@endpush

@section('content')
@verbatim

      <div class="page-header">
        <div class="page-header-media">
          <img src="/assets/img/banner.jpg" alt="" />
        </div>
        <div class="page-header-scrim"></div>
        <div class="container">
          <ul class="breadcrumb">
            <li><a href="/">Laman Utama</a></li>
            <li>Info Korporat</li>
            <li>Hebahan Integriti</li>
          </ul>
          <h1>Hebahan Integriti</h1>
        </div>
      </div>
      <section class="hb-intro">
        <div class="container">
          <div class="hb-lead">
            <p>
              Siri hebahan daripada Bahagian Integriti dan Governans Negeri
              Sabah (BIGONS) bagi melestarikan budaya integriti dalam kalangan
              penjawat awam.
            </p>
          </div>
          <nav class="hb-chips" aria-label="Senarai hebahan">
            <a href="#siri-01">Siri 01 · Dasar Antirasuah</a>
            <a href="#siri-02">Siri 02 · Tanda Nama</a>
            <a href="#slogan">Slogan Sabah Maju Jaya</a>
            <a href="#siri-03">Siri 03 · Tadbir Urus Baik</a>
            <a href="#laporkan-rasuah">Laporkan Rasuah</a>
          </nav>
        </div>
      </section>

      <section id="siri-01" class="hb-section section-tint">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">Siri 01 · 06 Januari 2023</span>
            <h2>
              Dasar Integriti dan Antirasuah Perkhidmatan Awam Negeri Sabah
            </h2>
            <p>
              Tahukah anda? Polisi Integriti dan Antirasuah Perkhidmatan Awam
              Negeri Sabah:
            </p>
          </div>
          <div class="hb-grid hb-grid-2">
            <div class="hb-card">
              <span class="hb-num">1</span>
              <p>
                Tidak melibatkan diri dalam sebarang bentuk jenayah rasuah,
                salah guna kuasa atau penyelewengan sama ada secara langsung
                atau tidak langsung.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">2</span>
              <p>
                Memupuk amalan integriti dan membudayakan nilai-nilai antirasuah
                dalam pelaksanaan tugas.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">3</span>
              <p>
                Menolak segala bentuk tawaran rasuah dan melaporkan kepada
                Suruhanjaya Pencegahan Rasuah Malaysia (SPRM) dengan seberapa
                segera.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">4</span>
              <p>
                Bertindak tegas terhadap mereka yang cuba melanggar
                undang-undang dan peraturan serta terhadap mereka yang cuba
                menggunakan integriti dan imej jabatan.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">5</span>
              <p>
                Menutup ruang dan peluang yang terdedah kepada amalan rasuah
                dalam semua urusan.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">6</span>
              <p>
                Bekerjasama sepenuhnya dengan mana-mana pihak dalam memerangi
                sebarang perlakuan jenayah rasuah, salah guna kuasa atau
                penyelewengan.
              </p>
            </div>
          </div>
          <p class="hb-source">
            <i class="fa-solid fa-book-open"></i> Sumber: Bahagian Integriti dan
            Governans Negeri Sabah, Pejabat Setiausaha Kerajaan Negeri.
          </p>
        </div>
      </section>

      <section id="siri-02" class="hb-section">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">Siri 02 · 01 Februari 2023</span>
            <h2>Kempen Pemakaian Tanda Nama</h2>
            <p>
              Setiap pegawai dan kakitangan diwajibkan memakai “Tanda Nama”
              dengan betul mengikut peraturan yang telah ditetapkan:
            </p>
          </div>
          <ol class="hb-list">
            <li>
              Diperbuat daripada plastik, huruf berwarna putih, berlatarkan
              hitam, 7.5cm x 2.5cm tanpa sebarang garis;
            </li>
            <li>Hanya satu nama sahaja digunakan;</li>
            <li>
              Tiada had saiz huruf yang ditetapkan dan tidak terlalu besar
              sehingga melebihi ruang yang ada;
            </li>
            <li>
              Gelaran darjah kebesaran, keturunan, profesion, kelulusan akademik
              atau “initial” tidak boleh dimasukkan;
            </li>
            <li>
              Nama jawatan dan logo jabatan tidak boleh digunakan untuk
              menghiasi tanda nama berkenaan;
            </li>
            <li>
              Tanda nama hendaklah disematkan pada baju di sebelah kiri dada;
              dan
            </li>
            <li>Tanda nama hendaklah diasingkan daripada pas keselamatan.</li>
          </ol>
          <p class="hb-source">
            <i class="fa-solid fa-book-open"></i> Sumber: Buku Arahan
            Perkhidmatan Awam Negeri Sabah, Muka Surat 49, No 109.
          </p>
        </div>
      </section>

      <section id="slogan" class="hb-section section-tint">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">Edisi Khas 2023</span>
            <h2>Slogan “Sabah Maju Jaya”</h2>
            <p>Tahukah anda?</p>
          </div>
          <div class="hb-grid hb-grid-3">
            <div class="hb-card">
              <span class="hb-num">1</span>
              <p>
                Jata kerajaan British North Borneo meletakkan cogan kata “PERGO
                ET PERAGO” yang membawa maksud “Saya Laksanakan dan Capai” telah
                diinspirasikan dijadikan cogan kata “Sabah Maju Jaya” pada jata
                negeri Sabah.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">2</span>
              <p>
                Cogan kata “Sabah Maju Jaya” diangkat sebagai hala tuju negeri
                dengan Hasrat untuk membawa citra inklusiviti, pemilikan
                bersama, kesatuan dan pertanggungjawaban setiap anak watan untuk
                menjayakan agenda pembangunan Negeri.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num">3</span>
              <p>
                Cogan kata “Sabah Maju Jaya” pada Jata negeri Sabah yang
                termaktub dalam Jadual Kedua, Bahagian II, Perlembagaan Negeri
                Sabah diangkat sebagai Hala Tuju Pelan Pembangunan Negeri Sabah
                dan dinamakan sebagai Pelan Pembangunan Sabah Maju Jaya 1.0
                (2021-2025).
              </p>
            </div>
          </div>
          <p class="hb-source">
            <i class="fa-solid fa-book-open"></i> Sumber: Buku Perlembagaan
            Negeri Sabah dan Buku Hala Tuju Sabah Maju Jaya, Pelan Pembangunan
            Sabah Maju Jaya 1.0 (2021-2023).
          </p>
        </div>
      </section>

      <section id="siri-03" class="hb-section">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">Siri 03 · 22 Mac 2023</span>
            <h2>Amalkan Tadbir Urus Baik</h2>
            <p>
              Dilarang menggunakan kenderaan gunasama jabatan atas urusan
              peribadi, seperti:
            </p>
          </div>
          <div class="hb-grid hb-grid-4">
            <div class="hb-card">
              <span class="hb-num hb-ban"><i class="fa-solid fa-ban"></i></span>
              <p>Hantar dan ambil anak pergi dan balik sekolah.</p>
            </div>
            <div class="hb-card">
              <span class="hb-num hb-ban"><i class="fa-solid fa-ban"></i></span>
              <p>
                Pergi pusat membeli belah dan bercuti bersama keluarga, rakan
                atau rakan sekerja.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num hb-ban"><i class="fa-solid fa-ban"></i></span>
              <p>
                Menggunakan kenderaan tanpa arahan rasmi dan kebenaran pegawai
                yang diberi kuasa.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-num hb-ban"><i class="fa-solid fa-ban"></i></span>
              <p>
                Membawa kenderaan gunasama jabatan balik ke rumah tanpa
                kebenaran bertulis rasmi daripada ketua jabatan.
              </p>
            </div>
          </div>
          <p class="hb-source">
            <i class="fa-solid fa-book-open"></i> Sumber: Amalan tadbir urus
            baik ini diselaraskan dengan prinsip yang ditetapkan dalam
            Pekeliling Pengurusan Kenderaan Kerajaan Negeri Sabah, 20 April
            2020.
          </p>
        </div>
      </section>

      <section id="laporkan-rasuah" class="hb-section section-tint">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">Edisi Khas 01</span>
            <h2>Laporkan Rasuah, Tanggungjawab Bersama</h2>
            <p>Langkah-langkah memberi maklumat yang berkualiti:</p>
          </div>
          <div class="hb-grid hb-grid-3">
            <div class="hb-card">
              <span class="hb-step">Langkah 01</span>
              <p>
                Memberikan maklumat yang menjurus dan tidak terlalu umum.
                Kumpulkan maklumat dan sampaikan isi penting seperti
                <em>When, where, who, what, why, how</em>.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-step">Langkah 02</span>
              <p>
                Nyatakan nama dan maklumat perhubungan dengan lengkap. SPRM
                menerima maklumat daripada pengadu yang tidak dikenali, tetapi
                adalah lebih penting maklumat anda diperoleh oleh pihak SPRM
                bagi memudahkan tindakan selanjutnya.
              </p>
            </div>
            <div class="hb-card">
              <span class="hb-step">Langkah 03</span>
              <p>
                Sila lengkapkan maklumat dan susuli dengan tindakan proaktif
                sehingga laporan (aduan) dapat diterima dan diberikan perhatian.
              </p>
            </div>
          </div>
          <div class="hb-contact">
            <h3>Laporkan rasuah dalam talian</h3>
            <ul>
              <li>
                <i class="fa-solid fa-phone"></i
                ><span><strong>Talian Bebas Tol</strong>1-800-88-6000</span>
              </li>
              <li>
                <i class="fa-solid fa-envelope"></i
                ><span><strong>E-mel</strong>info@sprm.gov.my</span>
              </li>
              <li>
                <i class="fa-solid fa-message"></i
                ><span><strong>SMS</strong>+6019-6000 696</span>
              </li>
              <li>
                <i class="fa-solid fa-location-dot"></i
                ><span
                  ><strong>Alamat</strong>SPRM Negeri Sabah, 88400 Kota
                  Kinabalu, Sabah</span
                >
              </li>
            </ul>
            <p class="hb-motto">“Rasuah Dihina, Maruah Dibina”</p>
          </div>
          <p class="hb-source">
            <i class="fa-solid fa-book-open"></i> Sumber: Portal sprm.gov.my
          </p>
        </div>
      </section>

      <section class="hb-section" id="bigons">
        <div class="container">
          <div class="hb-head">
            <span class="hb-badge">BIGONS</span>
            <h2>Hubungi Bahagian Integriti dan Governans Negeri Sabah</h2>
            <p>Melestarikan Budaya Integriti Dalam Kalangan Penjawat Awam.</p>
          </div>
          <div class="hb-grid hb-grid-4">
            <a
              class="hb-card hb-link"
              href="https://skn.sabah.gov.my/bigons"
              target="_blank"
              rel="noopener noreferrer"
              ><span class="hb-num"><i class="fa-solid fa-globe"></i></span>
              <p><strong>Laman sesawang</strong>skn.sabah.gov.my/bigons</p></a
            >
            <div class="hb-card">
              <span class="hb-num"><i class="fa-solid fa-phone"></i></span>
              <p><strong>Urus setia BIGONS</strong>088-369263</p>
            </div>
            <div class="hb-card">
              <span class="hb-num"><i class="fa-solid fa-envelope"></i></span>
              <p><strong>E-mel</strong>admin.uins@sabah.gov.my</p>
            </div>
            <a
              class="hb-card hb-link"
              href="https://i-adu.sabah.gov.my"
              target="_blank"
              rel="noopener noreferrer"
              ><span class="hb-num"><i class="fa-solid fa-bullhorn"></i></span>
              <p><strong>Sistem aduan i-Adu</strong>i-Adu.sabah.gov.my</p></a
            >
          </div>
        </div>
      </section>
    
@endverbatim
@endsection
