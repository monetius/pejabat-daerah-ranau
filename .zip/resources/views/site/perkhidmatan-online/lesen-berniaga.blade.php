@extends('layouts.site')

@section('title', 'Permohonan Lesen Berniaga - Pejabat Daerah Ranau')
@section('description', 'Permohonan lesen berniaga dalam talian, panduan memohon dan borang ulasan - Pejabat Daerah Ranau, Sabah.')
@section('body_class', 'has-banner')

@push('styles')
  <link rel="stylesheet" href="{{ asset('assets/css/lesen.css') }}">
@endpush

@section('content')
@verbatim

      <div class="page-header">
        <div class="page-header-media">
          <img src="/assets/img/banner.jpg" alt="" />
        </div>
        <div class="page-header-scrim"></div>
        <div class="container">
          <ul class="breadcrumb">
            <li><a href="/">Laman Utama</a></li>
            <li>Perkhidmatan Online</li>
            <li>Permohonan Lesen Berniaga</li>
          </ul>
          <h1>Permohonan Lesen Berniaga - update ui</h1>
        </div>
      </div>
      <section class="lb-intro">
        <div class="container">
          <div class="lb-lead">
            <p>
              Permohonan lesen berniaga bagi Daerah Ranau dibuat secara dalam
              talian melalui portal Digital Sabah. Sila rujuk panduan dan borang
              ulasan di bawah sebelum menghantar permohonan anda.
            </p>
          </div>
        </div>
      </section>

      <section>
        <div class="container">
          <div class="svc-grid">
            <a
              class="svc-card svc-card-primary"
              href="https://portal.digitalsabah.gov.my/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <span class="svc-icon"
                ><i class="fa-solid fa-file-signature"></i
              ></span>
              <h3>Permohonan Lesen Berniaga</h3>
              <p>
                Hantar permohonan lesen berniaga anda secara dalam talian
                melalui portal Digital Sabah.
              </p>
              <span class="svc-cta"
                >Mohon Sekarang
                <i class="fa-solid fa-arrow-up-right-from-square"></i
              ></span>
            </a>
            <a
              class="svc-card"
              href="https://www.youtube.com/watch?v=i8llvj0nSUY"
              target="_blank"
              rel="noopener noreferrer"
            >
              <span class="svc-icon"><i class="fa-brands fa-youtube"></i></span>
              <h3>Panduan Memohon Lesen Berniaga</h3>
              <p>
                Tonton video panduan cara memohon lesen berniaga di YouTube.
              </p>
              <span class="svc-cta"
                >Tonton Video
                <i class="fa-solid fa-arrow-up-right-from-square"></i
              ></span>
            </a>
            <a
              class="svc-card"
              href="https://drive.google.com/file/d/1GWitmaEpEDdgFJewOdUXJT5U2Qixs2r8/view"
              target="_blank"
              rel="noopener noreferrer"
            >
              <span class="svc-icon"
                ><i class="fa-solid fa-file-lines"></i
              ></span>
              <h3>Borang Ulasan Permohonan Lesen Berniaga</h3>
              <p>
                Buka borang ulasan permohonan lesen berniaga (Google Drive).
              </p>
              <span class="svc-cta"
                >Buka Borang
                <i class="fa-solid fa-arrow-up-right-from-square"></i
              ></span>
            </a>
          </div>
        </div>
      </section>

      <section>
        <div class="container">
          <div class="notice-block">
            <h2>Ada pertanyaan?</h2>
            <p>
              Untuk sebarang pertanyaan berkaitan permohonan lesen berniaga,
              sila
              <a href="/hubungi-kami/alamat"
                >hubungi Pejabat Daerah Ranau</a
              >. Waktu urusan: Isnin - Jumaat, 8.00 pagi - 5.00 petang (pejabat
              ditutup pada hujung minggu dan cuti umum).
            </p>
          </div>
        </div>
      </section>
    
@endverbatim
@endsection
